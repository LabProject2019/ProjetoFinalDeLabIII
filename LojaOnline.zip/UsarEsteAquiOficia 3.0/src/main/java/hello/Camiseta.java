package hello;

public class Camiseta 
{
	//14050239
	private String codigoCamiseta;

	private Especificacao_Camiseta espc;
	
	public Camiseta(String codigoCamiseta, Especificacao_Camiseta espc) {
		super();
		this.codigoCamiseta = codigoCamiseta;
		this.espc = espc;
	}
	
	public String getCodigoCamiseta() {
		return codigoCamiseta;
	}

	public void setCodigoCamiseta(String codigoCamiseta) {
		this.codigoCamiseta = codigoCamiseta;
	}

	public Especificacao_Camiseta getEspc() {
		return espc;
	}


	public void setEspc(Especificacao_Camiseta espc) {
		this.espc = espc;
	}
}

