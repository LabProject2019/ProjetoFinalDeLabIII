package hello;

public class Genero {
	private int gen_cod;
	private String gen_nome;
	
	public Genero(int genero_cod,String genero_nome) {
		gen_cod = genero_cod;
		gen_nome = genero_nome;
	}
	public int getGen_cod() {
		return gen_cod;
	}
	public void setGen_cod(int gen_cod) {
		this.gen_cod = gen_cod;
	}
	public String getGen_nome() {
		return gen_nome;
	}
	public void setGen_nome(String gen_nome) {
		this.gen_nome = gen_nome;
	}
	
}
