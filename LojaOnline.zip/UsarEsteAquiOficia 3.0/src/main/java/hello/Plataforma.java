package hello;

public class Plataforma {
	private int pla_cod;
	private String pla_nome;
	
	public Plataforma(int codigo_pla,String nome_pla) {
		this.pla_cod = codigo_pla;
		this.pla_nome = nome_pla;
	}
	
	public int getPla_cod() {
		return pla_cod;
	}
	public void setPla_cod(int pla_cod) {
		this.pla_cod = pla_cod;
	}
	public String getPla_nome() {
		return pla_nome;
	}
	public void setPla_nome(String pla_nome) {
		this.pla_nome = pla_nome;
	}
}
