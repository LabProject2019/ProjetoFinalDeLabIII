 package hello;


import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedList;

//03/05/2019:
import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Query;



public class Model {
	
	// 03/05/2019:
	ObjectContainer camiseta  = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),"bd/camisetas.db4o");
	ObjectContainer jogo = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),"bd/jogos.db4o");
	ObjectContainer usuarios = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),"bd/usuarios.db4o");
	ObjectContainer genero = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),"bd/generos.db4o");
	ObjectContainer plataforma = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),"bd/plataformas.db4o");
	ObjectContainer tamanho = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),"bd/tamanhos.db4o");
	ObjectContainer cor = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(),"bd/cores.db4o");
	
//_________GAMES_________
	private List<Game> games = new LinkedList<Game>();

	//ADD jogo
	public void addGame(Game addGame){ // OK
		// 03/05/2019:
		jogo.store(addGame);
	    jogo.commit();
	}
	
	//ADD genero
	public void addGenero(Genero addGenero){ // OK
		// 03/05/2019:
		genero.store(addGenero);
		genero.commit();
	}
	//ADD plataforma
	public void addPlataforma(Plataforma addPlataforma){ // OK
	// 03/05/2019:
		plataforma.store(addPlataforma);
		plataforma.commit();
	}
	
//Querys
	//Query Game
	public List<Game> criarQueryGame(){
		Query query = jogo.query();
		query.constrain(Game.class);
		ObjectSet<Game> allGame = query.execute();
		return allGame;
	}
	
	//Query Genero
	public List<Genero> criarQueryGenero(){
		Query query = genero.query();
		query.constrain(Genero.class);
		ObjectSet<Genero> allGeneros = query.execute();
		return allGeneros;
	}
	//Query Plataforma
	public List<Plataforma> criarQueryPlataforma(){
		// 21/05/2019:
					
		Query query = plataforma.query();
		query.constrain(Plataforma.class);
		ObjectSet<Plataforma> allPlataformas = query.execute();
		return allPlataformas;
	}
//	
		
	//Formatacao para enviar para a tabela
	public String formatarListaJogosTabele(List<Game> listaJogos){
		// 14/05/2019:
			
		JSONArray lista = new JSONArray();
			
		for(Game jogo: listaJogos) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("codigoGame", jogo.getCodigoGame());
				
			JSONObject espc = new JSONObject();
			espc.put("genero", buscarGeneroCod(jogo.getEspc().getGenero()));
			espc.put("nome", jogo.getEspc().getNome());
			espc.put("plataforma", buscarPlataformaCod(jogo.getEspc().getPlataforma()));
			jsonObj.put("espc", espc);
				
			lista.put(jsonObj);
		}
			
		return lista.toString();
	}
		
//Buscar codigo Jogo
	public Game buscarCodigoGame(String codigoGame){   // fazer html
		
		// 03/05/2019:
		List<Game> allGames = criarQueryGame();
			
	    for(Game gameAtual:allGames){
	    	if(gameAtual.getCodigoGame().equals(codigoGame)){
	    		return gameAtual;
	    	} 	
	    }	    
	    return null;	
	}
	
	public Game UpdateGame(Game jogoAlterado) {
		List<Game> allGames = criarQueryGame();
		
		for(Game gameAtual:allGames){
			if(gameAtual.getCodigoGame().equals(gameAtual.getCodigoGame())){
				Query query = this.jogo.query();
				query.constrain(Game.class);
				
				query.descend("codigoGame").constrain(jogoAlterado.getCodigoGame());
				ObjectSet result = query.execute();
				Game preGame = (Game) result.next();
				
				preGame.getEspc().setGenero(jogoAlterado.getEspc().getGenero());
				preGame.getEspc().setNome(jogoAlterado.getEspc().getNome());
				preGame.getEspc().setPlataforma(jogoAlterado.getEspc().getPlataforma());
				
				this.jogo.store(preGame);
				this.jogo.commit();
				
				break;
			}
		}
		return jogoAlterado;
	}
	
//Buscar com genero(int),nome(String) do jogo e plataforma(int)
	public List<Game> buscarEspecificacao(Especificacao esp){  // OK
		
		// 03/05/2019:
		List<Game> gamesEncontrados = new LinkedList<Game>();	
		List<Game> allGames = criarQueryGame();
							
		for(Game gameAtual:allGames){
			 if(esp.compararJog(gameAtual.getEspc())) gamesEncontrados.add(gameAtual);
		}
		return gamesEncontrados;
	}

//Buscas de 2 em 2
	//busca por genero e nome
	public List<Game> buscarGeneroNome(int gen, String nome){
		List<Game> gamesEncontrados = new LinkedList<Game>();	
		List<Game> allGames = criarQueryGame();
		
		for(Game gameAtual:allGames){
			 if(gameAtual.getEspc().compararJogGenNome(gen, nome)) gamesEncontrados.add(gameAtual);
		}
		return gamesEncontrados;
	}
	
	//busca por genero e plataforma
	public List<Game> buscarGeneroPla(int gen, int pla){
		List<Game> gamesEncontrados = new LinkedList<Game>();	
		List<Game> allGames = criarQueryGame();
		
		for(Game gameAtual:allGames){
			 if(gameAtual.getEspc().compararJogGenPla(gen, pla)) gamesEncontrados.add(gameAtual);
		}
		return gamesEncontrados;
	}
	
	//busca por nome e plataforma
	public List<Game> buscarNomePla(String nome, int pla){
		List<Game> gamesEncontrados = new LinkedList<Game>();	
		List<Game> allGames = criarQueryGame();
		
		for(Game gameAtual:allGames){
			 if(gameAtual.getEspc().compararJogNomePla(nome, pla)) gamesEncontrados.add(gameAtual);
		}
		return gamesEncontrados;
	}
//
	
//Genero
	//buscar jogos pelo gen_cod
	public List<Game> buscarGenero(int generoBuscado){ // OK
		// 03/05/2019:
		List<Game> gamesEncontrados = new LinkedList<Game>();			
		List<Game> allGames = criarQueryGame();					
					
		for(Game gameAtual:allGames){
			if(gameAtual.getEspc().getGenero() == generoBuscado) gamesEncontrados.add(gameAtual);
		}
		return gamesEncontrados;
	}
		
	//Buscar codigo do genero pelo genero_nome
	public int buscarGeneroCodigo(String generoNome) {		
		List<Genero> allGeneros = criarQueryGenero();
			
		for(Genero generoAtual:allGeneros) {
			if(generoAtual.getGen_nome().equals(generoNome))return generoAtual.getGen_cod();
		}
		return 0;
	}
		
	//buscar o nome do genero pelo gen_cod
	public String buscarGeneroCod(int generoCod) {
		List<Genero> allGeneros = criarQueryGenero();
			
		for(Genero generoAtual:allGeneros) {
			if(generoAtual.getGen_cod() == generoCod) return generoAtual.getGen_nome();
		}
		return "";
	}   
//
	
//nome Jogo
	//buscar lista de jogos pelo nome
	public List<Game> buscarNome(String nome){ // OK
		
		// 03/05/2019:
		List<Game> gamesEncontrados = new LinkedList<Game>();
		List<Game> allGames = criarQueryGame();				
		
		for(Game gameAtual:allGames){
			if(gameAtual.getEspc().getNome().equals(nome)) gamesEncontrados.add(gameAtual);
		}
		return gamesEncontrados;
	}
//
	
//plataforma	
	
	//buscar jogos pelo pla_cod
	public List<Game> buscarPlataforma(int plataforma){  // OK
			
		// 03/05/2019:
		List<Game> gamesEncontrados = new LinkedList<Game>();	
		List<Game> allGames = criarQueryGame();	
					
		for(Game gameAtual:allGames){
				if(gameAtual.getEspc().getPlataforma() == plataforma) gamesEncontrados.add(gameAtual);
		}
		return gamesEncontrados;
	}
		
	//Buscar codigo da plataforma pelo nome_plataforma
	public int buscarPlataformaCodigo(String plataformaNome) {		
		List<Plataforma> allPlataformas =  criarQueryPlataforma();
			
		for(Plataforma plataformaAtual:allPlataformas) {
			if(plataformaAtual.getPla_nome().equals(plataformaNome))return plataformaAtual.getPla_cod();
		}
		return 0;
	}
		
	//buscar pla_nome pelo pla_cod
	public String buscarPlataformaCod(int plaCod) {
		List<Plataforma> allPlataformas =  criarQueryPlataforma();
		
		for(Plataforma plataformaAtual:allPlataformas) {
			if(plataformaAtual.getPla_cod() == plaCod)return plataformaAtual.getPla_nome();
		}
		return "";
	}	
//
	public List<Game> getGame(){
		return games;
	}
	
	
//________________________________________CAMISA________________________________________//
	
	private List<Camiseta> camisas = new LinkedList<Camiseta>();
//Adds
	//Camiseta
	public void addCamiseta(Camiseta addCamiseta){ // OK
		// 03/05/2019:
		camiseta.store(addCamiseta);
		camiseta.commit();
	}
	//Tamaho
	public void addTamanho(Tamanho addTam) {
		tamanho.store(addTam);
		tamanho.commit();
	}
	//Cor
	public void addCor(Cor addC) {
		cor.store(addC);
		cor.commit();
	}
//

//Querys
	//Camiseta
	public List<Camiseta> criarQueryCamiseta(){
		Query query = camiseta.query();
		query.constrain(Camiseta.class);
		ObjectSet<Camiseta> allCamisetas = query.execute();
		return allCamisetas;
	}
	//Tamaho
	public List<Tamanho> criarQueryTamanho(){
		Query query = tamanho.query();
		query.constrain(Tamanho.class);
		ObjectSet<Tamanho> allTamanhos = query.execute();
		return allTamanhos;
	}
	//Cor
	public List<Cor> criarQueryCor(){
		Query query = cor.query();
		query.constrain(Cor.class);
		ObjectSet<Cor> allCores = query.execute();
		return allCores;
	}
//
	
	//Formatacao para enviar para a tabela
	public String formatarListaCamisetasTabela(List<Camiseta> listaCamisetas){
				
		JSONArray lista = new JSONArray();
				
		for(Camiseta camiseta: listaCamisetas) {
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("codigoCamiseta", camiseta.getCodigoCamiseta());
					
			JSONObject espc = new JSONObject();
			espc.put("tamanho", buscarTamanhoCod(camiseta.getEspc().getTamanho()));
			espc.put("estampa", camiseta.getEspc().getEstampa());
			espc.put("cor", buscarCorCod(camiseta.getEspc().getCor()));
			jsonObj.put("espc", espc);
					
			lista.put(jsonObj);
		}
				
		return lista.toString();
	}
	
	public Camiseta buscarCodigo(String codigoCamiseta){ // fazer html
		// 03/05/2019:
		List<Camiseta> allCamisetas = criarQueryCamiseta();
					
		for(Camiseta camisetaAtual:allCamisetas){
			if(camisetaAtual.getCodigoCamiseta() == codigoCamiseta){
				return camisetaAtual;
			}
			    	
		}    
		return null;	
	}
	
	
	public List<Camiseta> buscarEspecificacao_Camiseta(Especificacao_Camiseta espC){ // OK
		
		// 03/05/2019:
		List<Camiseta> camisasEncontradas = new LinkedList<Camiseta>();
					
		List<Camiseta> allCamisetas = criarQueryCamiseta();						
				
		for(Camiseta camisetaAtual:allCamisetas){
			if(espC.comparar_camiseta(camisetaAtual.getEspc())) camisasEncontradas.add(camisetaAtual);
		}
				
		return camisasEncontradas;	
	}
	
//Buscas de 2 em 2
	//busca por 
	public List<Camiseta> buscarTamanhoEstampa(int tamanho, String estampa){
		List<Camiseta> camisetasEncontradas = new LinkedList<Camiseta>();	
		List<Camiseta> allCamisetas = criarQueryCamiseta();
			
		for(Camiseta camisetaAtual:allCamisetas){
			if(camisetaAtual.getEspc().comparar_camisetaTE(tamanho, estampa))camisetasEncontradas.add(camisetaAtual) ;
		}
		return camisetasEncontradas;
	}
		
	//busca por genero e plataforma
	public List<Camiseta> buscarTamanhoCor(int tamanho, int cor){
		List<Camiseta> camisetasEncontradas = new LinkedList<Camiseta>();	
		List<Camiseta> allCamisetas = criarQueryCamiseta();
			
		for(Camiseta camisetaAtual:allCamisetas){
			if(camisetaAtual.getEspc().comparar_camisetaTC(tamanho, cor))camisetasEncontradas.add(camisetaAtual) ;
		}
		return camisetasEncontradas;
	}
		
	//busca por nome e plataforma
	public List<Camiseta> buscarEstampaCor(String estampa, int cor){
		List<Camiseta> camisetasEncontradas = new LinkedList<Camiseta>();	
		List<Camiseta> allCamisetas = criarQueryCamiseta();
			
		for(Camiseta camisetaAtual:allCamisetas){
			if(camisetaAtual.getEspc().comparar_camisetaEC(estampa, cor))camisetasEncontradas.add(camisetaAtual) ;
		}
		return camisetasEncontradas;
	}
//
	
//Tamanho
	//Fazer a busca apenas pelo tamanho da camiseta
	public List<Camiseta> buscarTamanho(int tamanhoCamiseta){ // OK
		// 03/05/2019:
		List<Camiseta> camisasEncontradas = new LinkedList<Camiseta>();
		List<Camiseta> allCamisetas = criarQueryCamiseta(); 
		
		for(Camiseta camisetaAtual:allCamisetas) {
			if(camisetaAtual.getEspc().getTamanho() == tamanhoCamiseta) camisasEncontradas.add(camisetaAtual);
		}
		return camisasEncontradas;
	}
	
	//Buscar codigo do genero pelo genero_nome
	public int buscarCodigoTamanho(String tamanhoNome) {		
		List<Tamanho> allTamanhos = criarQueryTamanho();
				
		for(Tamanho tamanhoAtual:allTamanhos) {
			if(tamanhoAtual.getNome_tam().equals(tamanhoNome))return tamanhoAtual.getCod_tam();
		}
		return 0;
	}
			
	//buscar o nome do genero pelo gen_cod
	public String buscarTamanhoCod(int tamCod) {
		List<Tamanho> allTamanhos = criarQueryTamanho();
				
		for(Tamanho tamanhoAtual:allTamanhos) {
			if(tamanhoAtual.getCod_tam() == tamCod) return tamanhoAtual.getNome_tam();
		}
		return "";
	}   
//
	
//Estampa
	public List<Camiseta> buscarEstampa(String estampaCamiseta){
		// 08/05/2019:
		List<Camiseta> camisasEncontradas = new LinkedList<Camiseta>();			
		List<Camiseta> allCamisetas = criarQueryCamiseta();		
				
		for(Camiseta camisetaAtual:allCamisetas) {
			if(camisetaAtual.getEspc().getEstampa().equals(estampaCamiseta)) camisasEncontradas.add(camisetaAtual);
		}
		return camisasEncontradas;
	}
//
	
//Cor
	public List<Camiseta> buscarCor(int corCamiseta){
		List<Camiseta> camisasEncontradas = new LinkedList<Camiseta>();			
		List<Camiseta> allCamisetas = criarQueryCamiseta();		
				
		for(Camiseta camisetaAtual:allCamisetas) {
			if(camisetaAtual.getEspc().getCor() == corCamiseta) camisasEncontradas.add(camisetaAtual);
		}
		return camisasEncontradas;
	}
	
	//Buscar 
	public int buscarCodigoCor(String nomeCor) {		
		List<Cor> allCores =  criarQueryCor();
				
		for(Cor corAtual:allCores) {
			if(corAtual.getNome_cor().equals(nomeCor))return corAtual.getCod_cor();
		}
		return 0;
	}
			
	//buscar 
	public String buscarCorCod(int corCod) {
		List<Cor> allCores =  criarQueryCor();
			
		for(Cor corAtual:allCores) {
			if(corAtual.getCod_cor() == corCod)return corAtual.getNome_cor();
		}
		return "";
	}	
//	
	public List<Camiseta> getCamiseta(){
		return camisas;
	}

}
