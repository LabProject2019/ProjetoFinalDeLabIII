package hello;

import static spark.Spark.*;


public class MainServer {
	
	final static Model model = new Model();
	
    public static void main(String[] args) {

		// Get port config of heroku on environment variable
        ProcessBuilder process = new ProcessBuilder();
        Integer port;
        if (process.environment().get("PORT") != null) {
            port = Integer.parseInt(process.environment().get("PORT"));
        } else {
            port = 9999;
        }
        port(port);

		//Servir conteudo html, css e javascript
		staticFileLocation("/static");

		inicializarGames();

		Controller controller = new Controller(model);
		
		//game
		controller.buscarGame();
		controller.buscarGameGenero();
		controller.buscarGameNome();
		controller.buscarGamePlataforma();
		controller.adicionarGame();
		controller.buscarAllGames();
		controller.buscarAllGeneros();
		controller.buscarAllJogosNome();
		controller.buscarAllPlataformas();
		controller.buscarGameGenero();
		controller.buscarGameGenNome();
		controller.buscarGameGenPla();
		controller.buscarGameNomePla();
		controller.updateGame();
		
		//camiseta
		controller.buscarCamiseta();
		controller.buscarCamisetaTamanho();
		controller.buscarCamisetaEstampa();
		controller.buscarCamisetaCor();
		controller.adicionarCamiseta();
		controller.buscarAllCamisetas();
		controller.buscarAllEstampas();
		controller.buscarAllTamanhos();
		controller.buscarAllCores();
		controller.buscarCamEstCor();
		controller.buscarCamTamCor();
		controller.buscarCamTamEst();
    }  
    
    public static void inicializarGames(){
    	
    }
}
