package hello;

import static spark.Spark.get;

import java.util.List;

import com.google.gson.Gson;

public class Controller {
	
	private Model model;
	
	public Controller(Model model){
		this.model = model;
	}
/////////////////////////////////Jogo///////////////////////////////////
	//Adicionar Jogo
	public void adicionarGame() {
		get("/addJogo/:codigoGame/:genero/:nome/:plataforma", (req, res) -> {
			model.addGame(new Game(req.params(":codigoGame"), new Especificacao(model.buscarGeneroCodigo(req.params(":genero")), req.params(":nome"), model.buscarPlataformaCodigo(req.params(":plataforma")))));
			return new Gson().toJson("Adicionado");	
		});
	}
	
	//Adicionar Genero
	//Adicionar Plataforma
	
	//Buscar Todos os jogos sem atributos 
		// 14/05/2019:
	public void updateGame() {
		get("/updateGame/:codigoGame/:genero/:nome/:plataforma", (req, res) -> {
		model.UpdateGame(new Game(req.params(":codigoGame"), new Especificacao(model.buscarGeneroCodigo(req.params(":genero")), req.params(":nome"), model.buscarPlataformaCodigo(req.params(":plataforma")))));
		return new Gson().toJson("Up");	
		});
	}
	
	public void buscarAllGames(){
		get("/jogoAll/", (req, res) -> {		
			return new Gson().toJson(model.formatarListaJogosTabele(model.criarQueryGame()));
		});
	}
		
//Buscar jogo todos os atributos
	public void buscarGame(){
		get("/jogoAll/:genero/:nome/:plataforma", (req, res) -> {
			
			Especificacao espec = new Especificacao(model.buscarGeneroCodigo(req.params(":genero")), req.params(":nome"), model.buscarPlataformaCodigo(req.params(":plataforma")));	
			List<Game> gamesEncontrados = model.buscarEspecificacao(espec);	
			return new Gson().toJson(model.formatarListaJogosTabele(gamesEncontrados));
		});
	}
	
//Buscar de 2 em 2	
	public void buscarGameGenNome() {
		get("/jogoGeNome/:genero/:nome", (req, res) -> {	
			List<Game> gamesEncontrados = model.buscarGeneroNome(model.buscarGeneroCodigo(req.params(":genero")), req.params(":nome"));	
			return new Gson().toJson(model.formatarListaJogosTabele(gamesEncontrados));
		});
	}
	
	public void buscarGameGenPla() {
		get("/jogoGePla/:genero/:plataforma", (req, res) -> {
			List<Game> gamesEncontrados = model.buscarGeneroPla(model.buscarGeneroCodigo(req.params(":genero")), model.buscarPlataformaCodigo(req.params(":plataforma")));	
			return new Gson().toJson(model.formatarListaJogosTabele(gamesEncontrados));
		});
	}
	
	public void buscarGameNomePla() {
		get("/jogoNomePla/:nome/:plataforma", (req, res) -> {
			List<Game> gamesEncontrados = model.buscarNomePla(req.params(":nome"),model.buscarPlataformaCodigo(req.params(":plataforma")));	
			return new Gson().toJson(model.formatarListaJogosTabele(gamesEncontrados));
		});
	}
//
	
//Genero
	//Buscar todos os generos
	public void buscarAllGeneros() {
		get("/generoAll/", (req, res) -> {		
			return new Gson().toJson(model.criarQueryGenero());
		});
	}
	//Buscar Lista de jogos pelo genero
	public void buscarGameGenero(){
		get("/jogoGenero/:genero", (req, res) -> {
			List<Game> gamesEncontrados = model.buscarGenero(model.buscarGeneroCodigo(req.params(":genero")));	
			return new Gson().toJson(model.formatarListaJogosTabele(gamesEncontrados));
		});
	}
//
	
//Nome
	//Todos os nomes de jogos
	public void buscarAllJogosNome() {
		get("/nomeAll/", (req, res) -> {		
			return new Gson().toJson(model.criarQueryGame());
		});
	}
	//Lista de jogos pelo nome
	public void buscarGameNome(){
		get("/jogoNome/:nome", (req, res) -> {
			List<Game> gamesEncontrados = model.buscarNome(req.params(":nome"));	
			return new Gson().toJson(model.formatarListaJogosTabele(gamesEncontrados));
		});
	}
//
	
//Plataforma
	//Todos as plataformas
	public void buscarAllPlataformas() {
		get("/plataformaAll/", (req, res) -> {		
			return new Gson().toJson(model.criarQueryPlataforma());
		});
	}
	//Lista de jogos pela plataforma
	public void buscarGamePlataforma(){
		get("/jogoPlataforma/:plataforma", (req, res) -> {
			List<Game> plataformasEncontrados = model.buscarPlataforma(model.buscarPlataformaCodigo(req.params(":plataforma")));	
			return new Gson().toJson(model.formatarListaJogosTabele(plataformasEncontrados));
		});
	}
//
	
/////////////////////////////////Camiseta///////////////////////////////////
	//Adicionar Camiseta
	public void adicionarCamiseta() {
		get("/addCamiseta/:codigo/:tamanho/:estampa/:cor", (req, res) -> {
			model.addCamiseta(new Camiseta(req.params(":codigo"), new Especificacao_Camiseta(model.buscarCodigoTamanho(req.params(":tamanho")), req.params(":estampa"),model.buscarCodigoCor(req.params(":cor")))));
			return new Gson().toJson("a");		
		});
	}
	//Buscar a lista de camisetas toda
	public void buscarAllCamisetas() {
		get("/camisetaAll/", (req, res) -> {		
			return new Gson().toJson(model.formatarListaCamisetasTabela(model.criarQueryCamiseta()));
		});
	}
	//Buscar com todos os atributos
	public void buscarCamiseta() {
		get("camisetaAll/:tamanho/:estampa/:cor", (req,res) -> {
			Especificacao_Camiseta especC = new Especificacao_Camiseta(model.buscarCodigoTamanho(req.params(":tamanho")),req.params(":estampa"),model.buscarCodigoCor( req.params(":cor")));
			List<Camiseta> camisasEncontradas = model.buscarEspecificacao_Camiseta(especC);
			return new Gson().toJson(model.formatarListaCamisetasTabela(camisasEncontradas));
		});
	}
//Buscar de 2 em 2	
	public void buscarCamTamEst() {
		get("/camisetaTamEst/:tamanho/:estampa", (req, res) -> {	
			List<Camiseta> camisetasEncontrados = model.buscarTamanhoEstampa(model.buscarCodigoTamanho(req.params(":tamanho")),req.params(":estampa"));	
			return new Gson().toJson(model.formatarListaCamisetasTabela(camisetasEncontrados));
		});
	}
		
	public void buscarCamTamCor() {
		get("/camisetaTamCor/:tamanho/:cor", (req, res) -> {
			List<Camiseta> camisetasEncontrados = model.buscarTamanhoCor(model.buscarCodigoTamanho(req.params(":tamanho")), model.buscarCodigoCor(req.params(":cor")));	
			return new Gson().toJson(model.formatarListaCamisetasTabela(camisetasEncontrados));
		});
	}
		
	public void buscarCamEstCor() {
		get("/camisetaEstCor/:estampa/:cor", (req, res) -> {
			List<Camiseta> camisetasEncontrados = model.buscarEstampaCor(req.params(":estampa"), model.buscarCodigoCor(req.params(":cor")));	
			return new Gson().toJson(model.formatarListaCamisetasTabela(camisetasEncontrados));
		});
	}
//
	
//Tamanho
	public void buscarAllTamanhos() {
		get("/tamanhoAll/", (req, res) -> {		
			return new Gson().toJson(model.criarQueryTamanho());
		});
	}
	public void buscarCamisetaTamanho(){
	get("/camisetaTamanho/:tamanho", (req, res) -> {
		List<Camiseta> camisasEncontradas = model.buscarTamanho(model.buscarCodigoTamanho(req.params(":tamanho")));
		return new Gson().toJson(model.formatarListaCamisetasTabela(camisasEncontradas));
	});
}	
	
//Estampa
	public void buscarAllEstampas() {
		get("/estampaAll/", (req, res) -> {		
			return new Gson().toJson(model.criarQueryCamiseta());
		});
	}
	public void buscarCamisetaEstampa() {
		get("/camisetaEstampa/:estampa", (req,res) ->{
			List<Camiseta> camisasEncontradas = model.buscarEstampa(req.params(":estampa"));
			return new Gson().toJson(model.formatarListaCamisetasTabela(camisasEncontradas));
		});
	}
	
//Cor
	public void buscarAllCores() {
		get("/corAll/", (req, res) -> {		
			return new Gson().toJson(model.criarQueryCor());
		});
	}
	public void buscarCamisetaCor(){
		get("/camisetaCor/:cor", (req, res) -> {
			List<Camiseta> camisasEncontradas = model.buscarCor(model.buscarCodigoCor(req.params(":tamanho")));
			return new Gson().toJson(model.formatarListaCamisetasTabela(camisasEncontradas));
		});
	}
}
