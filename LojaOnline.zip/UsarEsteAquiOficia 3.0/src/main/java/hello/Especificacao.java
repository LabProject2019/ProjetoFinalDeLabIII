package hello;

public class Especificacao 
{
	private int genero;
	private String nome;
	private int plataforma;
	
	public Especificacao(int genero, String nome, int plataforma) 
	{
		this.genero = genero;
		this.nome = nome;
		this.plataforma = plataforma;
	}
	
	public int getGenero() {
		return genero;
	}

	public void setGenero(int genero) {
		this.genero = genero;
	}

	public int getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(int plataforma) {
		this.plataforma = plataforma;
	}

	public String getNome() 
	{
		return nome;
	}
	public void setNome(String nome) 
	{
		this.nome = nome;
	}

	
	//Metodos de Comparacao
	
	//Comparacao usando todas as especificacoes
	public boolean compararJog(Especificacao esp) {
		
		if(genero==esp.genero && nome.equals(esp.nome) && plataforma==esp.plataforma){
			return true;
		}
		else
		{
			return false;
		}
	}
	//Genero e Nome
	public boolean compararJogGenNome(int gen, String nomeJogo ) {
		if(genero == gen && nome.equals(nomeJogo)){
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//Genero e Plataforma
	public boolean compararJogGenPla(int gen, int pla) {
		if(genero == gen && plataforma == pla){
			return true;
		}
		else
		{
			return false;
		}
	}
	
	//Nome e Plataforma
	public boolean compararJogNomePla(String nomeJogo, int pla) {
		
		if(nome.equals(nomeJogo) && plataforma == pla){
			return true;
		}
		else
		{
			return false;
		}
	}
}
