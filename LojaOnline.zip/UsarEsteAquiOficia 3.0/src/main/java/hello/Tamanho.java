package hello;

public class Tamanho {
	int cod_tam;
	String nome_tam;
	
	public Tamanho(int cod, String tamanho) {
		this.cod_tam = cod;
		this.nome_tam = tamanho;
	}
	
	public int getCod_tam() {
		return cod_tam;
	}
	public void setCod_tam(int cod_tam) {
		this.cod_tam = cod_tam;
	}
	public String getNome_tam() {
		return nome_tam;
	}
	public void setNome_tam(String nome_tam) {
		this.nome_tam = nome_tam;
	}
}
