package hello;

public class Especificacao_Camiseta 
{
	private int tamanho;
	private String estampa;
	private int cor;
	
	public Especificacao_Camiseta(int tamanho, String estampa, int cor) {
		this.tamanho = tamanho;
		this.estampa = estampa;
		this.cor = cor;
	}
	
	public int getTamanho() {
		return tamanho;
	}

	public void setTamanho(int tamanho) {
		this.tamanho = tamanho;
	}

	public String getEstampa() {
		return estampa;
	}

	public void setEstampa(String estampa) {
		this.estampa = estampa;
	}

	public int getCor() {
		return cor;
	}

	public void setCor(int cor) {
		this.cor = cor;
	}	
	
	public boolean comparar_camiseta(Especificacao_Camiseta espC){
		if(tamanho == espC.tamanho && estampa.equals(espC.estampa) && cor == espC.cor){
			return true;
		} else {
			return false;
		}
	}
	//
	public boolean comparar_camisetaTE(int tam, String est ) {
		if(tamanho == tam && estampa.equals(est)){
			return true;
		}
		else
		{
			return false;
		}
	}
		
	//
	public boolean comparar_camisetaTC(int tam, int corCod) {
		if(tamanho == tam && cor == corCod){
			return true;
		}
		else
		{
			return false;
		}
	}
		
	//
	public boolean comparar_camisetaEC(String est, int corCod) {
			
		if(estampa.equals(est) && cor == corCod){
			return true;
		}
		else
		{
			return false;
		}
	}
}
