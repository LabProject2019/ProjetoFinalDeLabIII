package hello;

public class Cor {
	int cod_cor;
	String nome_cor;
	
	public Cor(int cod, String cor) {
		this.cod_cor = cod;
		this.nome_cor = cor;
	}
			
	public int getCod_cor() {
		return cod_cor;
	}
	public void setCod_cor(int cod_cor) {
		this.cod_cor = cod_cor;
	}
	public String getNome_cor() {
		return nome_cor;
	}
	public void setNome_cor(String nome_cor) {
		this.nome_cor = nome_cor;
	}
}
