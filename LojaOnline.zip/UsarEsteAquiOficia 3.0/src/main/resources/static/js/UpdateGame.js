$(document).ready(function(){	
		$("#alterar").click(function() {
		
		var codigo = $( "codigoGame").val();
		var genero = $( "#genero option:selected" ).text();
		var nome = $( "#nome" ).val();
		var plataforma = $( "#plataforma option:selected" ).text();
		
		var url = `/updateGame/${codigoGame}/${genero}/${nome}/${plataforma}`;
		
		$.getJSON(url, function(data) {
			$.each(data, function(i){					
				alert("Jogo Alterado");
			});			
		});
	});
});
