$(document).ready(function(){
			
			$("#genero").append(`<option value="">Escolha um genero</option>`);
			
			$.getJSON("/generoAll/", function(data) {		
				$.each(data, function(i){			
					$("#genero").append(
						`<option value="${this.gen_cod}">
							${this.gen_nome}
						</option>`); 
				});				
			});
			
			$("#plataforma").append(`<option value="">Escolha uma plataforma</option>`);
						
				$.getJSON("/plataformaAll/", function(data) {
								
					$.each(data, function(i){			
						$("#plataforma").append(
							`<option value="${this.pla_nome}">
								${this.pla_nome}
							</option>`);
					});				
				});
							
			$("#adicionar").click(function(){
				var codigoGame = $("#codigoGame").val();
				var genero = $("#genero option:selected").text();
				var nome = $("#nome").val();
				var plataforma = $("#plataforma option:selected").text();
				
				var url = `/addJogo/${codigoGame}/${genero}/${nome}/${plataforma}`; //dica de oro.
				
				$.getJSON(url, function(data) {
						
					alert("Jogo Cadastrado");
					location.reload(true);
						
				});				
			});
});
