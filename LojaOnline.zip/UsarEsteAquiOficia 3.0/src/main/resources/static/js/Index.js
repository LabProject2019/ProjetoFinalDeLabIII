$(document).ready(function(){	
			
	$("#genero").append(`<option value="">Todos os Generos</option>`);
			
	$.getJSON("/generoAll/", function(data) {
					
		$.each(data, function(i){			
			$("#genero").append(
				`<option value="${this.gen_cod}">
					${this.gen_nome}
				</option>`); 
		});				
	});
			
	$("#nome").append(`<option value="">Nome de todos os Jogos</option>`);
			
	$.getJSON("/nomeAll/", function(data) {
		var jogosEncontrados = [];
					
		$.each(data, function(i){
			if(jogosEncontrados.indexOf(this.espc.nome) == -1){
				jogosEncontrados.push(this.espc.nome);
							
				$("#nome").append(
					`<option value="${this.espc.nome}">
						${this.espc.nome}
					</option>`);
			}
		});
					
	});
			
	$("#plataforma").append(`<option value="">Todas as plataformas</option>`);
			
	$.getJSON("/plataformaAll/", function(data) {
					
		$.each(data, function(i){			
			$("#plataforma").append(
				`<option value="${this.pla_nome}">
					${this.pla_nome}
				</option>`);
		});
					
	});

	$("#busca").click(function() {

		var genero = $( "#genero option:selected" ).text();
		var nome = $( "#nome option:selected" ).text();
		var plataforma = $( "#plataforma option:selected" ).text();
		var ListaJogos = [];
					
		$("#jogosEncontrados").empty();
		if(genero == "Todos os Generos" && nome == "Nome de todos os Jogos" && plataforma == "Todas as plataformas"){
			var url = "/jogoAll/";
		}else if(genero != "Todos os Generos" && nome == "Nome de todos os Jogos" && plataforma == "Todas as plataformas"){
			var url = "/jogoGenero/"+genero;
		}else if(genero == "Todos os Generos" && nome != "Nome de todos os Jogos" && plataforma == "Todas as plataformas"){
			var url = "/jogoNome/"+nome;
		}else if(genero == "Todos os Generos" && nome == "Nome de todos os Jogos" && plataforma != "Todas as plataformas"){
			var url = "/jogoPlataforma/"+plataforma;
		}else if(genero != "Todos os Generos" && nome != "Nome de todos os Jogos" && plataforma == "Todas as plataformas"){
			var url = "/jogoGeNome/"+genero+"/"+nome;
		}else if(genero != "Todos os Generos" && nome == "Nome de todos os Jogos" && plataforma != "Todas as plataformas"){
			var url = "/jogoGePla/"+genero+"/"+plataforma;
		}else if(genero == "Todos os Generos" && nome != "Nome de todos os Jogos" && plataforma != "Todas as plataformas"){
			var url = "/jogoNomePla/"+nome+"/"+plataforma;
		}else{
			var url = "/jogoAll/"+genero+"/"+nome+"/"+plataforma+"";	
		}
		$.getJSON(url, function(data) {
			data = JSON.parse(data);		
			$.each(data, function(i){					
				ListaJogos.push("<tr> <td>"+ this.codigoGame +"</td><td>"+ this.espc.genero + "</td><td>"+ this.espc.nome + "</td><td>"+ this.espc.plataforma + "</td></tr>");
			});
			$("#jogosEncontrados").append(ListaJogos);				
		});
	});
});
