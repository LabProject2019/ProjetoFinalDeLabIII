$(document).ready(function(){
			
		$("#tamanho").append(`<option value="">Todos os Tamanhos</option>`);
			
		$.getJSON("/tamanhoAll/", function(data) {
					
		$.each(data, function(i){			
			$("#tamanho").append(
				`<option value="${this.cod_tam}">
					${this.nome_tam}
				</option>`); 
			});				
		});
			
		$("#cor").append(`<option value="">Todas as Cores</option>`);
			
		$.getJSON("/corAll/", function(data) {
					
		$.each(data, function(i){			
			$("#cor").append(
				`<option value="${this.nome_cor}">
					${this.nome_cor}
				</option>`);
			});
					
		});	
			
		$("#adicionar").click(function(){
					
			var codigoCamisa = $( "#codigoCamisa" ).val();
			var tamanho  = $( "#tamanho" ).val();
			var estampa = $( "#estampa" ).val();
			var cor = $( "#cor" ).val();
				
			var url = `/addCamiseta/${codigoCamisa}/${tamanho}/${estampa}/${cor}`; //dica de oro.
				
			$.getJSON(url, function(data) {
					
				alert("Camiseta Cadastrada");
					location.reload(true);
					
			});	
		});		
});

	