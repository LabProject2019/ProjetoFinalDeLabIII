$(document).ready(function(){	
			
	$("#tamanho").append(`<option value="">Todos os Tamanhos</option>`);
			
	$.getJSON("/tamanhoAll/", function(data) {
					
		$.each(data, function(i){			
			$("#tamanho").append(
				`<option value="${this.cod_tam}">
					${this.nome_tam}
				</option>`); 
		});				
	});
			
	$("#estampa").append(`<option value="">Todas as Estampas</option>`);
			
	$.getJSON("/estampaAll/", function(data) {
		var camisetasEncontradas = [];
					
		$.each(data, function(i){
			if(camisetasEncontradas.indexOf(this.espc.estampa) == -1){
				camisetasEncontradas.push(this.espc.estampa);
							
				$("#estampa").append(
					`<option value="${this.espc.estampa}">
						${this.espc.estampa}
					</option>`);
			}
		});
					
	});
			
	$("#cor").append(`<option value="">Todas as Cores</option>`);
			
	$.getJSON("/corAll/", function(data) {
					
		$.each(data, function(i){			
			$("#cor").append(
				`<option value="${this.nome_cor}">
					${this.nome_cor}
				</option>`);
		});
					
	});

	$("#busca").click(function() {

		var tamanho = $( "#tamanho option:selected" ).text();
		var estampa = $( "#estampa option:selected" ).text();
		var cor = $( "#cor option:selected" ).text();
		var ListaCamisetas = [];
					
		$("#camisetasEncontradas").empty();
		if(tamanho == "Todos os Tamanhos" && estampa == "Todas as Estampas" && cor == "Todas as Cores"){
			var url = "/camisetaAll/";
		}else if(tamanho != "Todos os Tamanhos" && estampa == "Todas as Estampas" && cor == "Todas as Cores"){
			var url = "/camisetaTamanho/"+tamanho;
		}else if(tamanho == "Todos os Tamanhos" && estampa != "Todas as Estampas" && cor == "Todas as Cores"){
			var url = "/camisetaEstampa/"+estampa;
		}else if(tamanho == "Todos os Tamanhos" && estampa == "Todas as Estampas" && cor != "Todas as Cores"){
			var url = "/camisetaCor/"+cor;
		}else if(tamanho != "Todos os Tamanhos" && estampa != "Todas as Estampas" && cor == "Todas as Cores"){
			var url = "/camisetaTamEst/"+tamanho+"/"+estampa;
		}else if(tamanho != "Todos os Tamanhos" && estampa == "Todas as Estampas" && cor != "Todas as Cores"){
			var url = "/camisetaTamCor/"+tamanho+"/"+cor;
		}else if(tamanho == "Todos os Tamanhos" && estampa != "Todas as Estampas" && cor != "Todas as Cores"){
			var url = "/camisetaEstCor/"+estampa+"/"+cor;;
		}else{
			var url = "camisetaAll/"+tamanho+"/"+estampa+"/"+cor;	
		}
		$.getJSON(url, function(data) {
			data = JSON.parse(data);		
			$.each(data, function(i){					
				ListaCamisetas.push("<tr> <td>"+ this.codigoCamiseta +"</td><td>"+ this.espc.tamanho + "</td><td>"+ this.espc.estampa + "</td><td>"+ this.espc.cor + "</td></tr>");
			});
			$("#camisetasEncontradas").append(ListaCamisetas);				
		});
	});
});
